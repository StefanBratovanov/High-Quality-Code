﻿using BangaloreUniversityLearningSystem.Core;

namespace buls
{
    public class Program
    {
        public static void Main()
        {
            var engine = new BangaloreUniversityEngine();
            engine.Run();
        }
    }
}