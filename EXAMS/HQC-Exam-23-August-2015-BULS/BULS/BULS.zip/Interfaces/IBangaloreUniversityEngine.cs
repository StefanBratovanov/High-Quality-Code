﻿
namespace BangaloreUniversityLearningSystem.Interfaces
{
    public interface IBangaloreUniversityEngine
    {
        void Run();
    }
}
